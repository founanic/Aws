# coming-soon-webpage

In this webpage, We have created a creative and extraordinary "Coming-soon" webpage for those whose website is in construction and they need some time for for there website to build. Those guys can use this webpage for that time.

### Watch demo [here](https://vishalps2606.github.io/coming-soon-webpage)

## Screenshot of the design
![fiver gig](https://user-images.githubusercontent.com/70359874/132979294-640ee9da-dcec-46d0-8a59-b89a803856e0.jpg)

###### (My window is not activated that's why the window activated thumbnail is showing in bottom-right corner.)
